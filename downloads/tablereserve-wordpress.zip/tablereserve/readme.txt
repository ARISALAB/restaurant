=== TableReserve ===
Contributors: arakronservices
Tags: restaurant, reservations, booking, table booking, restaurant booking
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Online table reservations for restaurants, cafés and bars. Add a booking form or a "Book a table" button to any page.

== Description ==

TableReserve lets your guests book a table on your website 24/7. You see every reservation in real time in your TableReserve dashboard, on your phone or computer.

* Booking form on any page, or a "Book a table" button that opens it in a popup
* Automatic confirmation email to the guest, with a one-click cancellation link
* Instant email to the restaurant for every new booking and cancellation
* English and Greek, chosen automatically from the visitor's language
* Works with the block editor (TableReserve block), shortcodes and page builders
* Reservation analytics: busiest hours, cancellations, most popular days

**Getting started**

1. Create a restaurant account at [tablereserve.gr](https://tablereserve.gr/en/). The first 14 days are free, no card required.
2. Install this plugin and go to **Settings → TableReserve**.
3. Enter your restaurant ID (from your booking link, after `?shop=`).
4. Add the **TableReserve** block to a page, or use the shortcode `[tablereserve]`.

**Shortcodes**

* `[tablereserve]` – the booking form on the page
* `[tablereserve mode="button"]` – a button that opens the booking form in a popup
* `[tablereserve mode="button" label="Reserve now" color="#b91c1c"]` – custom button text and color
* `[tablereserve lang="en"]` – force English (or `el` for Greek)
* `[tablereserve shop="another_restaurant"]` – a different restaurant ID

== External services ==

This plugin displays the online booking form of the TableReserve service, which is operated by AR Akron Services (Greece).

* **What it is used for:** to show your restaurant's booking page inside your website and let your guests make reservations.
* **What is sent and when:** when a page with the booking form is viewed, the visitor's browser loads the booking form from https://tablereserve.gr (standard request data such as IP address and browser type). When a guest makes a reservation, the details they enter (name, phone, email, date, time, party size, seating preference and comments) are sent to TableReserve and shared with the restaurant. No data from your WordPress database is sent.
* Terms of Service: https://tablereserve.gr/terms?lang=en
* Privacy Policy: https://tablereserve.gr/privacy?lang=en

A TableReserve account is required. New accounts include a 14-day free trial; after that a paid subscription is needed.

== Installation ==

1. Upload the `tablereserve` folder to `/wp-content/plugins/`, or install the plugin from **Plugins → Add New**.
2. Activate the plugin.
3. Go to **Settings → TableReserve** and enter your restaurant ID.
4. Add the TableReserve block or the `[tablereserve]` shortcode to any page.

== Frequently Asked Questions ==

= Where do I find my restaurant ID? =

In your TableReserve dashboard. It is the part of your booking link after `?shop=`. For example, in `tablereserve.gr/?shop=my_restaurant` the ID is `my_restaurant`.

= Do I need a TableReserve account? =

Yes. You can create one at tablereserve.gr in about two minutes. The first 14 days are free.

= Does it work with Elementor, Divi and other page builders? =

Yes. Add a shortcode widget/module and paste `[tablereserve]`.

= Which languages are supported? =

English and Greek. The form uses the visitor's browser language automatically, or you can set a fixed language.

= Where are reservations stored? =

In your TableReserve account, not in your WordPress database. You manage them from your TableReserve dashboard.

== Screenshots ==

1. The booking form on a restaurant website
2. The "Book a table" button and popup
3. Settings → TableReserve
4. The TableReserve block in the editor

== Changelog ==

= 1.0.0 =
* First release: block, shortcode, inline form and popup button, English and Greek.
