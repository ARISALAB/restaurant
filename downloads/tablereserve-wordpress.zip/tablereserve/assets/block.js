( function ( wp ) {
	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var PanelBody = wp.components.PanelBody;
	var TextControl = wp.components.TextControl;
	var SelectControl = wp.components.SelectControl;
	var Placeholder = wp.components.Placeholder;

	wp.blocks.registerBlockType( 'tablereserve/booking', {
		apiVersion: 2,
		title: 'TableReserve',
		description: __( 'Online table reservations for your restaurant.', 'tablereserve' ),
		icon: 'calendar-alt',
		category: 'widgets',
		keywords: [ 'reservation', 'booking', 'restaurant', 'table' ],
		attributes: {
			shop: { type: 'string', default: '' },
			mode: { type: 'string', default: 'inline' },
			lang: { type: 'string', default: '' },
			label: { type: 'string', default: '' }
		},
		edit: function ( props ) {
			var a = props.attributes;
			var set = function ( key ) { return function ( v ) { var o = {}; o[ key ] = v; props.setAttributes( o ); }; };
			return el( 'div', useBlockProps(),
				el( InspectorControls, null,
					el( PanelBody, { title: __( 'Booking form', 'tablereserve' ), initialOpen: true },
						el( TextControl, { label: __( 'Restaurant ID', 'tablereserve' ), help: __( 'Leave empty to use the ID from Settings → TableReserve.', 'tablereserve' ), value: a.shop, onChange: set( 'shop' ) } ),
						el( SelectControl, { label: __( 'Display', 'tablereserve' ), value: a.mode, onChange: set( 'mode' ), options: [
							{ label: __( 'Form on the page', 'tablereserve' ), value: 'inline' },
							{ label: __( 'Button that opens a popup', 'tablereserve' ), value: 'button' }
						] } ),
						el( SelectControl, { label: __( 'Language', 'tablereserve' ), value: a.lang, onChange: set( 'lang' ), options: [
							{ label: __( 'Default', 'tablereserve' ), value: '' },
							{ label: 'English', value: 'en' },
							{ label: 'Ελληνικά', value: 'el' }
						] } ),
						a.mode === 'button' ? el( TextControl, { label: __( 'Button text', 'tablereserve' ), value: a.label, onChange: set( 'label' ) } ) : null
					)
				),
				el( Placeholder, {
					icon: 'calendar-alt',
					label: 'TableReserve',
					instructions: ( a.mode === 'button' ? __( 'A "Book a table" button will appear here.', 'tablereserve' ) : __( 'Your booking form will appear here.', 'tablereserve' ) ) +
						( a.shop ? ' (' + a.shop + ')' : '' )
				} )
			);
		},
		save: function () { return null; }
	} );
} )( window.wp );
