<?php
/**
 * Plugin Name:       TableReserve
 * Plugin URI:        https://tablereserve.gr/en/
 * Description:       Add your TableReserve online booking form to any page, as an inline form or a "Book a table" button. Guests book in English or Greek and get an instant confirmation email.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Author:            AR Akron Services
 * Author URI:        https://tablereserve.gr/en/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tablereserve
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TABLERESERVE_VERSION', '1.0.0' );
define( 'TABLERESERVE_OPTION', 'tablereserve_settings' );

/**
 * Saved settings with defaults.
 */
function tablereserve_settings() {
	$defaults = array(
		'shop'  => '',
		'lang'  => '',
		'label' => '',
		'color' => '#2563eb',
	);
	$saved = get_option( TABLERESERVE_OPTION, array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

/**
 * Only letters, numbers and underscore are valid in a shop ID.
 */
function tablereserve_clean_shop( $shop ) {
	return strtolower( preg_replace( '/[^a-zA-Z0-9_]/', '', (string) $shop ) );
}

function tablereserve_register_assets() {
	wp_register_script(
		'tablereserve-embed',
		plugins_url( 'assets/tablereserve.js', __FILE__ ),
		array(),
		TABLERESERVE_VERSION,
		true
	);
}
add_action( 'init', 'tablereserve_register_assets' );

/**
 * Markup used by the shortcode and the block.
 */
function tablereserve_render( $atts ) {
	$s    = tablereserve_settings();
	$atts = shortcode_atts(
		array(
			'shop'  => $s['shop'],
			'mode'  => 'inline',
			'lang'  => $s['lang'],
			'label' => $s['label'],
			'color' => $s['color'],
		),
		$atts,
		'tablereserve'
	);

	$shop = tablereserve_clean_shop( $atts['shop'] );
	if ( '' === $shop ) {
		if ( current_user_can( 'manage_options' ) ) {
			return '<p><em>' . esc_html__( 'TableReserve: add your restaurant ID in Settings → TableReserve.', 'tablereserve' ) . '</em></p>';
		}
		return '';
	}

	wp_enqueue_script( 'tablereserve-embed' );

	$mode  = ( 'button' === $atts['mode'] ) ? 'button' : 'inline';
	$lang  = in_array( $atts['lang'], array( 'el', 'en' ), true ) ? $atts['lang'] : '';
	$color = sanitize_hex_color( $atts['color'] );

	$html  = '<div class="tablereserve-embed" data-tablereserve="' . esc_attr( $shop ) . '" data-mode="' . esc_attr( $mode ) . '"';
	if ( $lang ) {
		$html .= ' data-lang="' . esc_attr( $lang ) . '"';
	}
	if ( '' !== $atts['label'] ) {
		$html .= ' data-label="' . esc_attr( $atts['label'] ) . '"';
	}
	if ( $color ) {
		$html .= ' data-color="' . esc_attr( $color ) . '"';
	}
	$html .= '>';
	// Fallback for visitors without JavaScript.
	$html .= '<noscript><a href="' . esc_url( 'https://tablereserve.gr/?shop=' . $shop ) . '">' . esc_html__( 'Book a table online', 'tablereserve' ) . '</a></noscript>';
	$html .= '</div>';
	return $html;
}

/**
 * [tablereserve] shortcode.
 * Examples: [tablereserve]  [tablereserve mode="button" label="Book now"]  [tablereserve shop="my_restaurant" lang="en"]
 */
add_shortcode( 'tablereserve', 'tablereserve_render' );

/**
 * Block editor block (no build step).
 */
function tablereserve_register_block() {
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}
	wp_register_script(
		'tablereserve-block',
		plugins_url( 'assets/block.js', __FILE__ ),
		array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n' ),
		TABLERESERVE_VERSION,
		true
	);
	register_block_type(
		'tablereserve/booking',
		array(
			'editor_script'   => 'tablereserve-block',
			'render_callback' => 'tablereserve_render',
			'attributes'      => array(
				'shop'  => array( 'type' => 'string', 'default' => '' ),
				'mode'  => array( 'type' => 'string', 'default' => 'inline' ),
				'lang'  => array( 'type' => 'string', 'default' => '' ),
				'label' => array( 'type' => 'string', 'default' => '' ),
			),
		)
	);
}
add_action( 'init', 'tablereserve_register_block' );

/**
 * Block attributes left empty fall back to the plugin settings.
 */
add_filter(
	'shortcode_atts_tablereserve',
	function ( $out, $pairs, $atts ) {
		$s = tablereserve_settings();
		foreach ( array( 'shop', 'lang', 'label', 'color' ) as $key ) {
			if ( isset( $out[ $key ] ) && '' === $out[ $key ] ) {
				$out[ $key ] = $s[ $key ];
			}
		}
		return $out;
	},
	10,
	3
);

/* ---------------------------------------------------------------------------
 * Settings page: Settings → TableReserve
 * ------------------------------------------------------------------------ */

function tablereserve_admin_menu() {
	add_options_page(
		__( 'TableReserve', 'tablereserve' ),
		__( 'TableReserve', 'tablereserve' ),
		'manage_options',
		'tablereserve',
		'tablereserve_settings_page'
	);
}
add_action( 'admin_menu', 'tablereserve_admin_menu' );

function tablereserve_sanitize_settings( $input ) {
	$input = is_array( $input ) ? $input : array();
	$color = isset( $input['color'] ) ? sanitize_hex_color( $input['color'] ) : '';
	return array(
		'shop'  => isset( $input['shop'] ) ? tablereserve_clean_shop( $input['shop'] ) : '',
		'lang'  => ( isset( $input['lang'] ) && in_array( $input['lang'], array( 'el', 'en' ), true ) ) ? $input['lang'] : '',
		'label' => isset( $input['label'] ) ? sanitize_text_field( $input['label'] ) : '',
		'color' => $color ? $color : '#2563eb',
	);
}

function tablereserve_admin_init() {
	register_setting(
		'tablereserve',
		TABLERESERVE_OPTION,
		array( 'sanitize_callback' => 'tablereserve_sanitize_settings' )
	);
}
add_action( 'admin_init', 'tablereserve_admin_init' );

function tablereserve_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s = tablereserve_settings();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'TableReserve', 'tablereserve' ); ?></h1>
		<p>
			<?php esc_html_e( 'Take table reservations on your website. Your restaurant ID is shown in your TableReserve dashboard, in your booking link after ?shop=', 'tablereserve' ); ?>
		</p>
		<p>
			<a class="button" href="https://tablereserve.gr/en/#contact" target="_blank" rel="noopener"><?php esc_html_e( 'Create a free account', 'tablereserve' ); ?></a>
			<a class="button" href="https://tablereserve.gr/admin" target="_blank" rel="noopener"><?php esc_html_e( 'Open your dashboard', 'tablereserve' ); ?></a>
		</p>

		<form method="post" action="options.php">
			<?php settings_fields( 'tablereserve' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="tr-shop"><?php esc_html_e( 'Restaurant ID', 'tablereserve' ); ?></label></th>
					<td>
						<input id="tr-shop" class="regular-text" type="text" name="<?php echo esc_attr( TABLERESERVE_OPTION ); ?>[shop]" value="<?php echo esc_attr( $s['shop'] ); ?>" placeholder="my_restaurant">
						<p class="description"><?php esc_html_e( 'Example: if your booking link is tablereserve.gr/?shop=my_restaurant, your ID is my_restaurant.', 'tablereserve' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="tr-lang"><?php esc_html_e( 'Language', 'tablereserve' ); ?></label></th>
					<td>
						<select id="tr-lang" name="<?php echo esc_attr( TABLERESERVE_OPTION ); ?>[lang]">
							<option value="" <?php selected( $s['lang'], '' ); ?>><?php esc_html_e( 'Automatic (visitor\'s language)', 'tablereserve' ); ?></option>
							<option value="en" <?php selected( $s['lang'], 'en' ); ?>>English</option>
							<option value="el" <?php selected( $s['lang'], 'el' ); ?>>Ελληνικά</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="tr-label"><?php esc_html_e( 'Button text', 'tablereserve' ); ?></label></th>
					<td>
						<input id="tr-label" class="regular-text" type="text" name="<?php echo esc_attr( TABLERESERVE_OPTION ); ?>[label]" value="<?php echo esc_attr( $s['label'] ); ?>" placeholder="<?php esc_attr_e( 'Book a table', 'tablereserve' ); ?>">
						<p class="description"><?php esc_html_e( 'Used when you show the booking form as a button.', 'tablereserve' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="tr-color"><?php esc_html_e( 'Button color', 'tablereserve' ); ?></label></th>
					<td><input id="tr-color" type="color" name="<?php echo esc_attr( TABLERESERVE_OPTION ); ?>[color]" value="<?php echo esc_attr( $s['color'] ); ?>"></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'How to add it to a page', 'tablereserve' ); ?></h2>
		<p><?php esc_html_e( 'In the block editor, add the "TableReserve" block. Or paste one of these shortcodes:', 'tablereserve' ); ?></p>
		<p><code>[tablereserve]</code> — <?php esc_html_e( 'the booking form on the page', 'tablereserve' ); ?></p>
		<p><code>[tablereserve mode="button"]</code> — <?php esc_html_e( 'a button that opens the booking form in a popup', 'tablereserve' ); ?></p>

		<?php if ( $s['shop'] ) : ?>
			<h2><?php esc_html_e( 'Preview', 'tablereserve' ); ?></h2>
			<div style="max-width:760px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:8px;">
				<?php echo tablereserve_render( array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside tablereserve_render(). ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * "Settings" link on the Plugins screen.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=tablereserve' ) ) . '">' . esc_html__( 'Settings', 'tablereserve' ) . '</a>' );
		return $links;
	}
);
